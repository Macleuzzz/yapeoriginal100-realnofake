Esta webapp fue realizada para fines recreativos y de aprendizaje, descrubir una vulnerabilidad en Yape que incluye el nombre en el código QR.

Si recibes pagos por medio de Códigos QR siempre verificar la transacción.

Clave:123456

Los logos y nombres comerciales no son de mi propiedad.

Then, start [Rollup](https://rollupjs.org):

```bash
npm run dev
```

Navigate to [localhost:5000](http://localhost:5000). You should see your app running. Edit a component file in `src`, save it, and reload the page to see your changes.
